<?php

declare(strict_types=1);

namespace Auth0\SDK\Contract;

interface Auth0Event
{
}
